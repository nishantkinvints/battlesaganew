import React from 'react'

const Sectiontitle = (props) => {
    return (
        <div className="section_title">
            <h2>{props.title}</h2>
        </div>
    )
}

export default Sectiontitle
