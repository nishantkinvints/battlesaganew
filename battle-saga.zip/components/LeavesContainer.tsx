// import Leaf from "./Leaf";
// import DragonRight from '../assets/dragon-right.png';
// // import DragonSide from '../assets/DRAGON_SIDE copy.png';
// import DragonLeft from '..assets/dragon-left.png';
// import { motion } from 'framer-motion' ;

// const LeavesContainer = () => {
//     return (
//         <div>
//             {/* Two dragons */}
// 			<motion.div variants={{ leavesContainer }} initial="initial" animate="animate" className="absolute w-[400px] left-80 top-20">
// 				<Image src={DragonRight} objectFit="contain" />
// 			</motion.div>
			
// 			<div className="absolute w-[500px] right-72 translate-y-2 -translate-x-4 top-16">
// 				<Image src={DragonLeft} objectFit="contain" />
// 			</div>
//         </div>
//     )
// }

// export default LeavesContainer
